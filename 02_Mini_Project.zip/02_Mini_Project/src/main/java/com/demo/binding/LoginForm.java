package com.demo.binding;

import lombok.Data;

@Data
public class LoginForm {

	private String email;

	private String pwd;
}
