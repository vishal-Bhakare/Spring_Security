package com.demo.binding;

import lombok.Data;

@Data
public class EnquirySearchCriteria {

	private String classMode;

	private String courseName;

	private String enquiryStatus;

}
